ActiveRecord::Base.send(:include, ActiveModel::ForbiddenAttributesProtection)
